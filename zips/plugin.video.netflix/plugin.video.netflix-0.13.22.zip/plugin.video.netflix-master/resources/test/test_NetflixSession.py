# -*- coding: utf-8 -*-
# Module: NetflixSession
# Author: asciidisco
# Created on: 11.10.2017
# License: MIT https://goo.gl/5bMj3H

"""Tests for the `NetflixSession` module"""

import unittest
import mock
from resources.lib.NetflixSession import NetflixSession

class NetflixSessionTestCase(unittest.TestCase):
    pass
