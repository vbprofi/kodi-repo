# Burning Series Kodi Fork

edited the scripts to let you now watch movies and specials instead of just episodes
